//
//  Functions.swift
//  NotificationSystem
//
//  Created by Lev Rose on 11/15/22.
//

import Foundation
import UIKit


struct Functions{
//    var eatingSwitch = false
//    var drinkingSwitch = false
//    var movementSwitch = false
}
