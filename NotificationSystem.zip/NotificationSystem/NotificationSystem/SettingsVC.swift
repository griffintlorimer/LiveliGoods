//
//  SettingsVC.swift
//  NotificationSystem
//
//  Created by Lev Rose on 11/8/22.
//

import Foundation
import UIKit


class SettingsVC: ViewController, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource{
 
    let notifier = Notifications()
    let Goals_Section = 0
    let Eating_Section = 1
    let Drinking_Section = 2
    let Movement_Section = 3
    
    let screenWidth = UIScreen.main.bounds.height - 10
    let screenHeight = UIScreen.main.bounds.height/2

    
    let pickerView = UIPickerView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width - 10, height: UIScreen.main.bounds.height/2))
    let pickerAmounts = ["None", "Daily", "Semi-Regularly", "Regularly"]
   
    var selectedRow: Int = 0
    
    var eatReminders = "None"
    var drinkReminders = "None"
    var moveReminders = "None"

    var calGoal = 0
    var drinkGoal = 0
    var stepGoal = 0
    
    var eatSwitch = false
    var drinkSwitch = false
    var moveSwitch = false
    
    @IBOutlet weak public var theTable: UITableView!
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == Goals_Section{
            return goalCellTableViewCell().goals.count
        }else {
            return 2
        }
        
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == Goals_Section{
            return "Daily Goals"
        }else if section == Eating_Section{
            return notificationCellTableViewCell().notifications[0]
        }else if section == Drinking_Section{
            return notificationCellTableViewCell().notifications[1]
        }else if section == Movement_Section{
            return notificationCellTableViewCell().notifications[2]
        }
        
        return ""
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 25
    }
    
   
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        
        if indexPath.section == Goals_Section{

            
            let cell = theTable.dequeueReusableCell(withIdentifier: "goalCell") as! goalCellTableViewCell
            cell.configure(with: cell.goals[indexPath.row])
            cell.VC = self
            if (indexPath.row == Eating_Section-1){
                cell.myGoalNum.text = String(calGoal)
            }
            if (indexPath.row == Drinking_Section-1){
                cell.myGoalNum.text = String(drinkGoal)
            }
            if (indexPath.row == Movement_Section-1){
                cell.myGoalNum.text = String(stepGoal)
            }
            return cell
            
        } else if (indexPath.row == 0){
                let cell = theTable.dequeueReusableCell(withIdentifier: "notificationCell") as! notificationCellTableViewCell
            cell.configure(with: cell.notifications[indexPath.section-1], vc: self)
                return cell
        }
        let currSec = indexPath.section
        var currReminders = "None"
        
        if (currSec == Eating_Section){
            currReminders = eatReminders
        }
        if (currSec == Drinking_Section){
            currReminders = drinkReminders
        }
        if (currSec == Movement_Section){
            currReminders = moveReminders
        }
        
        let cell = theTable.dequeueReusableCell(withIdentifier: "notificationSubCell") as! notificationSubCell
        cell.configure(reminders: currReminders)
            return cell
        
        
     
    }
    

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        // for picker view
        if (indexPath.section != Goals_Section){
            let vc = UIViewController()
            vc.preferredContentSize = CGSize(width: screenWidth, height: screenHeight)



            pickerView.selectRow(selectedRow, inComponent: 0, animated: false)

            vc.view.addSubview(pickerView)
            pickerView.centerXAnchor.constraint(equalTo: vc.view.centerXAnchor).isActive = true
            pickerView.centerYAnchor.constraint(equalTo: vc.view.centerYAnchor).isActive = true
            let alert = UIAlertController(title: "Set Daily Goal", message: "", preferredStyle: .actionSheet)
            alert.setValue(vc, forKey: "contentViewController")
            alert.addAction(UIAlertAction(title: "cancel", style: .cancel, handler: {(UIAlertAction) in

            }))
            alert.addAction(UIAlertAction(title: "Select", style: .default, handler: {(UIAlertAction) in
                self.selectedRow = self.pickerView.selectedRow(inComponent: 0)

                
                if (indexPath.section == self.Eating_Section){
                    self.eatReminders = self.pickerAmounts[self.selectedRow]
                }else if (indexPath.section == self.Drinking_Section){
                    self.drinkReminders = self.pickerAmounts[self.selectedRow]
                } else{
                    self.moveReminders = self.pickerAmounts[self.selectedRow]
                }

                
                self.storeUserDefaults()
                self.notifier.loadNotifications()
                
            
                self.theTable.reloadData()
            }))

            self.present(alert, animated: true, completion: nil)

        }


        
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerAmounts.count
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 30))
        label.text = pickerAmounts[row]
        label.textColor = UIColor.black
        label.sizeToFit()
        return label
        
    }
   
    func loadUserDefaults(){
        
        calGoal =  UserDefaults.standard.integer(forKey: "calGoal")
        drinkGoal =  UserDefaults.standard.integer(forKey: "drinkGoal")
        stepGoal = UserDefaults.standard.integer(forKey: "stepGoal")

       eatReminders = UserDefaults.standard.string(forKey: "eatReminders") ?? "None"
        drinkReminders = UserDefaults.standard.string(forKey: "drinkReminders") ?? "None"
        moveReminders = UserDefaults.standard.string(forKey: "moveReminders") ?? "None"
        
        eatSwitch = UserDefaults.standard.bool(forKey: "eatSwitch")
        drinkSwitch = UserDefaults.standard.bool(forKey: "drinkSwitch")
        moveSwitch = UserDefaults.standard.bool(forKey: "moveSwitch")
        print("calgoal \(calGoal)")
                
    }
    
    func storeUserDefaults(){
        UserDefaults.standard.set(calGoal, forKey: "calGoal")
        UserDefaults.standard.set(drinkGoal, forKey: "drinkGoal")
        UserDefaults.standard.set(stepGoal, forKey: "stepGoal")
        
        UserDefaults.standard.set(eatReminders, forKey: "eatReminders")
        UserDefaults.standard.set(drinkReminders, forKey: "drinkReminders")
        UserDefaults.standard.set(moveReminders, forKey: "moveReminders")
        
        UserDefaults.standard.set(eatSwitch, forKey: "eatSwitch")
        UserDefaults.standard.set(drinkSwitch, forKey: "drinkSwitch")
        UserDefaults.standard.set(moveSwitch, forKey: "moveSwitch")
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
                
        loadUserDefaults()
        
        notifier.resetIntervals(food: eatReminders, drink: drinkReminders, walk: moveReminders)

        
        
        self.hideKeyboardWhenTappedAround()
        
        theTable.delegate = self
        theTable.dataSource = self
        theTable.backgroundColor = UIColor(named: "Background")
  
        
        theTable.register(notificationCellTableViewCell.nib(), forCellReuseIdentifier: notificationCellTableViewCell.identifier)
        theTable.register(goalCellTableViewCell.nib(), forCellReuseIdentifier: goalCellTableViewCell.identifier)
        theTable.register(notificationSubCell.nib(), forCellReuseIdentifier: notificationSubCell.identifier)
        
        pickerView.dataSource = self
        pickerView.delegate = self
       
    }

   
    
}
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}



