//
//  pedometer.swift
//  Test
//
//  Created by taih on 11/15/22.
//

import Foundation
